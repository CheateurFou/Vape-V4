# Vape-V4
Vape V4 is a ghost client for minecraft and it is the best 

To make the cheat work you should: 
download python:https://www.python.org/downloads/
![unknown](https://user-images.githubusercontent.com/119528195/209012792-3680a83f-e05f-4432-a23c-e147f83ace10.png)
then
pressing Windows + r and put cmd
Write the command "pip install -r requirements.txt" and you will be able to run vape 
![unknown1](https://user-images.githubusercontent.com/119528195/209012606-0ce35ef0-844c-4820-9e48-2db8ecbe98b2.png)
